// Nombre: Quintín, Apellidos: Mesa Romero, Titulación: GIM.
// email: quintinmr@correo.ugr.es, DNI o pasaporte: 78006011Q
// *********************************************************************

#include "latapeones.h"

using namespace glm;

Lata::Lata(const std::string& archivoTextura)
{
    NodoGrafoEscena * base_inferior = new NodoGrafoEscena();
    NodoGrafoEscena * cilindro_lata = new NodoGrafoEscena();
    NodoGrafoEscena * base_superior = new NodoGrafoEscena();

    Material * material_bases = new Material(0.1,0.6,2.0,50);
    base_inferior->agregar(material_bases);
    base_superior->agregar(material_bases);

    Material * material_cilindro = new Material(new Textura(archivoTextura),0.5,3.0,3.0,50);
    cilindro_lata->agregar(material_cilindro);
    base_inferior->agregar(new MallaRevolPLY("lata-pinf.ply",50));
    agregar(base_inferior);
    base_superior->agregar(new MallaRevolPLY("lata-psup.ply",50));
    agregar(base_superior);
    cilindro_lata->agregar(new MallaRevolPLY("lata-pcue.ply",50));
    agregar(cilindro_lata);

    ponerNombre("Lata");
    ponerIdentificador(-1);
}

LataCoca::LataCoca()
{
    agregar(new Lata("lata-coke.jpg"));
    ponerNombre("Lata de Coca-Cola");
    ponerIdentificador(1);

}

LataPepsi::LataPepsi()
{
    agregar(new Lata("lata-pepsi.jpg"));
    ponerNombre("Lata de Pepsi");
    ponerIdentificador(2);

}

LataUGR::LataUGR()
{
    agregar(new Lata("window-icon.jpg"));
    ponerNombre("Lata de la UGR");
    ponerIdentificador(3);

}

PeonMadera::PeonMadera()
{
    Textura * madera = new Textura("text-madera.jpg");
    agregar(scale(vec3(0.2,0.2,0.2)));
    agregar(translate(vec3(0.0,1.35,0.0)));
    agregar( new Material(madera, 0.25, 0.75, 3.0, 20));
    agregar( new MallaRevolPLY("peon.ply",50));

    ponerNombre("Peón de madera");
    ponerIdentificador(4);
}

PeonBlanco::PeonBlanco()
{
    agregar(scale(vec3(0.2,0.2,0.2)));
    agregar(translate(vec3(0.0,1.35,0.0)));
    agregar( new Material(0.25,0.8,0.1,30));
    agregar( new MallaRevolPLY("peon.ply",50));

    ponerNombre("Peón blanco");
    ponerIdentificador(5);

}

PeonNegro::PeonNegro()
{
    agregar(scale(vec3(0.2,0.2,0.2)));
    agregar(translate(vec3(0.0,1.35,0.0)));
    agregar( new Material(0.1,0.25,0.8,20));
    agregar( new MallaRevolPLY("peon.ply",50));

    ponerNombre("Peón negro");
    ponerIdentificador(6);

}

Latas::Latas()
{
    
    agregar(new LataCoca());
    agregar(translate(vec3(1.0,0.0,0.0)));
    agregar(new LataPepsi);
    agregar(translate(vec3(1.0,0.0,0.0)));
    agregar(new LataUGR);

    ponerNombre("Latas");
    ponerIdentificador(0);
}

Peones::Peones()
{
    agregar(translate(vec3(0.0, 0.0, 1.0)));
    agregar(new PeonMadera());
    agregar(translate(vec3(0.5, 0.0, 0.0)));
    agregar(new PeonBlanco());
    agregar(translate(vec3(0.5, 0.0, 0.0)));
    agregar(new PeonNegro());

    ponerNombre("Peones");
    ponerIdentificador(0);

}


LataPeones::LataPeones()
{
    NodoGrafoEscena * lata = new NodoGrafoEscena();
    lata->agregar(new Lata("lata-coke.jpg"));
    agregar(lata);
    agregar(translate(vec3(0.0, 0.0, 1.0)));
    agregar(new PeonMadera());
    agregar(translate(vec3(0.5, 0.0, 0.0)));
    agregar(new PeonBlanco());
    agregar(translate(vec3(0.5, 0.0, 0.0)));
    agregar(new PeonNegro());
    ponerNombre("Lata y peones");
}

VariasLataPeones::VariasLataPeones()
{
    agregar(new Latas());
    agregar(new Peones());

    ponerNombre("Varias latas y peones");
    ponerIdentificador(0);
}

